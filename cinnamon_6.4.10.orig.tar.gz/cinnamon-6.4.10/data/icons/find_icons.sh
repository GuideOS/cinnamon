#!/bin/sh

ls -1 | grep hicolor.*\.svg
ls -1 | grep hicolor.*\.png
