#! /bin/bash

pysassc ./cinnamon-sass/cinnamon.scss cinnamon.css
