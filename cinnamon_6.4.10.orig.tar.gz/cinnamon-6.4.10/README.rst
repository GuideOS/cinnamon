Cinnamon is a Linux desktop that provides advanced innovative features and a traditional user experience.

The desktop layout is similar to GNOME 2 with underlying technology forked from the GNOME Shell.
Cinnamon makes users feel at home with an easy-to-use and comfortable desktop experience.


Contributing
============
Cinnamon is on GitHub at https://github.com/linuxmint/cinnamon.

Note that some issues may not be with Cinnamon itself. For a list of related components,
please see https://projects.linuxmint.com/cinnamon/.


License
=======
Cinnamon is distributed under the terms of the GNU General Public License,
version 2 or later. See the COPYING file for details.

