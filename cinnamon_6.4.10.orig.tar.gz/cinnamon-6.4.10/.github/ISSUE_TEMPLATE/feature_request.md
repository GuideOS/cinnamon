---
name: Feature request (OBSOLETE)
about: Feature requests are no longer accepted here, please use https://github.com/orgs/linuxmint/discussions instead.
title: ""
labels: ["FEATURE REQUEST"]
assignees: ''

---

Please use:

https://github.com/orgs/linuxmint/discussions